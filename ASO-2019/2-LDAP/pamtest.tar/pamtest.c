/*
	This is a simple test-program, to see whether a
	PAM Authentication Chain succeeds or not.

	(C)opyright 2003 Tobias Heide <tucks@gmx.de>

	Version 0.2

	This program is free software; you can redistribute it and/or modify it
	under the terms of the GNU General Public License as published by the
	Free Software Foundation; either version 2 of the License, or (at your
	option) any later version.

	This program is distributed in the hope that it will be useful, but
	WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
	General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	675 Mass Ave, Cambridge, MA 02139, USA. 

	usage: ./pamtest <module-name> <username>
 */

#include <stdio.h>
#include <security/pam_appl.h>
#include <security/pam_misc.h>

int main (int argc, char** argv)
{
	static struct pam_conv my_conversation = {
		misc_conv,
		NULL
	};
	pam_handle_t *pamh = NULL;	// PAM-specific stuff

	char *pam_module = argv[1];	// First argumnt
	char *pam_user = argv[2];	// Second argument
	int rv;				// Return value

	if (argc != 3) {
		printf("pamtest Copyright (C) 2003 Tobias Heide <tucks@gmx.de>\n\n");
		printf("This program checks whether authentication as a specific\n");
		printf("user under a specific pam-module is successfull or not.\n\n");
		
		printf("This program is distributed under the terms of the\n");
		printf("GNU General Public License (GPL) Version 2 or later.\n");
		printf("Visit http://www.gnu.org for details.\n\n");
		
		printf("Usage: %s <module-name> <username>\n", argv[0]);
		exit(-1);
	}
	
	printf("Starting %s with module-name %s and username %s.\n", argv[0], pam_module, pam_user);

	/* Start PAM-Authentication  */
	if (PAM_SUCCESS == (rv = pam_start(pam_module, pam_user, &my_conversation, &pamh))) {
		printf("Successfully initialized the PAM-Library!\n");
		if (PAM_SUCCESS == (rv = pam_authenticate(pamh, 0))) {
			/* User has authenticated himself */
			printf("You are successfully authenticated as %s.\n", pam_user);
			if (PAM_SUCCESS == (rv = pam_acct_mgmt(pamh, 0))) {
				/* User is authorized to use service */
				printf("(pam_acct) Account-Part of PAM-Library successful for %s.\n", pam_user);
			} else {
				/* User is not authorized to use service */
				printf("(pam_acct) Account-Part of PAM-Library FAILED for %s.\n", pam_user);
				printf("PAM returned: %s\n", pam_strerror(pamh, rv));
			}
		} else {
			/* User has not authenticated himself successfully */
			printf("Authentication as user %s failed.\n", pam_user);
			printf("PAM returned: %s\n", pam_strerror(pamh, rv));
		}
	} else {
		printf("Error: Could not initialize the PAM-Library!\n");
		printf("PAM returned: %s\n", pam_strerror(pamh, rv));
	}

	if (PAM_SUCCESS == pam_end(pamh,rv)) {
		printf("PAM-Library successfully closed.\n");
		return 0;
	} else {
		pamh = NULL;
		printf("Error: PAM-Library could not be closed!\n");
		printf("PAM returned: %s\n", pam_strerror(pamh, rv));
	}
}

/*
int talkWithPAM (int msgCount, pam_message **msg, pam_response **rsp, void appdata_ptr)
{
	// TODO 
} */
